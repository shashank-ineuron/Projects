1. Use MSSQL Server and load Aventure Work database 
2. Create Kafka publisher and send MSSQL data to Kafka
3. Read Data from Kafka and Dump into Azure Blob Storage
4. Dump data from Azure blob Storage to Azure SQL Dataware house